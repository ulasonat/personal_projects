package yl9i70;

import java.awt.*;

/** This is a abstract class that Player and Dragon will extend. */
public abstract class MovingCharacter extends Sprite {

    public MovingCharacter(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }

}
