package yl9i70;

import java.awt.*;

/** The class to represent the 'door'.*/
public class Door extends Sprite {

    public Door(int x, int y, int width, int height, Image image) {
        super(x, y, width, height, image);
    }
}
